# Ex > 2022-07-08 3:06pm
https://universe.roboflow.com/detectron2-dhbdn/ex-blg53

Provided by a Roboflow user
License: MIT

